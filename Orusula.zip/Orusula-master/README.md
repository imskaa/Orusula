<h1 align="center">
  <br>
  <a href="https://github.com/imskaa">
    <img src="https://cdn130.picsart.com/296531077044211.png?r1024x1024" alt="Orusula bot" width="450">
  </a>
  </br>
  <br>
  Orusula
  </br>
</h1>

<h4 align="center">
  <br>Orusula 🕷️ is An Intelligent Bot Auto Shell Exploit and detect multiple types of Cms</br>
</h4>

<p align="center">
   <a href="https://github.com/imskaa/">
    <img src="https://img.shields.io/github/license/BrahimJarrar/Orusula">
  </a>

  <a href="https://pypi.org/project/Orusula/">
    <img src="https://img.shields.io/badge/pypi-Orusula-red.svg">
  </a>

  <a href="https://github.com/imskaa/">
      <img src="https://img.shields.io/github/issues/BrahimJarrar/Orusula">
  </a>
  <a href="https://travis-ci.com/BrahimJarrar/Orusula">
    <img src="https://api.travis-ci.com/BrahimJarrar/Orusula.svg">
  </a>
  <br></br>
  <img src="screenshot/00-00.PNG" width="750">
</p>

<p align="center">
  <a href="https://github.com/BrahimJarrar/Orusula/wiki">Orusula Wiki</a> •
  <a href="https://github.com/BrahimJarrar/Orusula/wiki/Usage">How To Use</a> •
  <a href="https://github.com/BrahimJarrar/Orusula/wiki/Compatibility-&-Dependencies">Compatibility</a> •
  <a href="https://github.com/BrahimJarrar/Orusula/wiki/Orusula-Library">Library</a> •
</p>

-------------------------------------

### _🕷️ Features_

- Detect cms (wordpress, joomla, prestashop, drupal, opencart, magento, lokomedia)
- Target informations gatherings
- Multi-threading on demand
- Checks for vulnerabilities
- Auto shell injector
- Exploit dork searcher

-------------------------------------

#### Joomla
- [x] [Com Jce            ]('#')
- [x] [Com Jwallpapers    ]('#')
- [x] [Com Jdownloads     ]('#')
- [x] [Com Jdownloads2    ]('#')
- [x] [Com Weblinks       ]('#')
- [x] [Com Fabrik         ]('#')
- [x] [Com Fabrik2        ]('#')
- [x] [Com Jdownloads Index]('#')
- [x] [Com Foxcontact     ]('#')
- [x] [Com Blog           ]('#')
- [x] [Com Users          ]('#')
- [x] [Com Ads Manager    ]('#')
- [x] [Com Sexycontactform]('#')
- [x] [Com Media          ]('#')
- [x] [Mod_simplefileupload]('#')
- [x] [Com Facileforms    ]('#')
- [x] [Com Facileforms    ]('#')
- [x] [Com extplorer      ]('#')

#### Wordpress
- [x] [AddBlockUrl]('#')
- [x] [Revslider Max]('#')
- [x] [barclaycart]('#')
- [x] [woocommerce]('#')
- [x] [Blaze SlideShow]('#')
- [x] [downloadsmanager]('#')
- [x] [Catpro Plugin]('#')
- [x] [wtff]('#')
- [x] [Powerzoomer]('#')
- [x] [FormCraft]('#')
- [x] [DreamWork]('#')
- [x] [cubed]('#')
- [x] [Gravity Forms]('#')
- [x] [Revslider Ajax]('#')
- [x] [Job Manager]('#')
- [x] [levoslideshow]('#')
- [x] [WP Mobile Detector]('#')
- [x] [Satoshi]('#')
- [x] [Pinboard]('#')
- [x] [Pitchprint]('#')
- [x] [Showbiz Pro]('#')
- [x] [Synoptic]('#')
- [x] [Cherry Plugin]('#')
- [x] [Wysija]('#')
- [x] [Simple ads manager]('#')
- [x] [dzs zoomsounds]('#')
- [x] [RightNow]('#')

#### Opencart
- [ ] [Opencart BruteForce]('#')

### _🕷️ Available command line options_

    usage: Orusula [options]

      -h, --help            show this help message and exit
      -u , --url            Target site
      -l , --list           list of sites urls
      -d , --dorks          dorks to get sites list. Soon
      -s , --scan           Cms scanner
      -t , --threads        Threading by default 10

-------------------------------------

### <img src="https://cdn1.iconfinder.com/data/icons/system-shade-circles/512/ubuntu-512.png" width="25">  Install Orusula on Ubuntu

```bash
$ git clone https://github.com/BrahimJarrar/Orusula.git
$ cd Orusula
$ chmod +x install.sh
$ ./install.sh
```


### <img src="http://icons.iconarchive.com/icons/blackvariant/button-ui-system-apps/256/Terminal-icon.png" width="25">  Install Orusula on Termux

```BASH
$ pkg update
$ pkg install -y git
$ git clone https://github.com/BrahimJarrar/Orusula.git
$ cd Orusula
$ chmod +x install.sh
$ ./install.sh
```


### <img src="https://upload.wikimedia.org/wikipedia/commons/c/c7/Windows_logo_-_2012.png" width="20">  Install Orusula in Windows

- [click here](https://github.com/imskaa/Orusula/archive/master.zip) to download Orusula
- download and install python3
- unzip **Orusula-master.zip** in ***Desktop***
- open the command prompt **cmd**.
```
> cd Desktop/Orusula-master/
> python Orusula.py
```


-------------------------------------

### 💙 Imported scripts

- [x] [Cms Checker](https://github.com/anouarbensaad/vulnx)
- [x] [5 Joomla exploits](https://github.com/anouarbensaad/vulnx)
- [x] [README.md xD](https://github.com/anouarbensaad/vulnx)

-------------------------------------

### :warning: Warning!

***I Am Not Responsible of any Illegal Use!***

-------------------------------------

### _🕷️ Contribution & License_

You can contribute in following ways:

- [Report bugs & add issues](https://github.com/imskaa/Orusula/issues/new)
- Search for new vulnerability
- Develop plugins
- Searching Exploits
- Give suggestions **(Ideas)** to make it better

Do you want to have a conversation in private? Discord : https://discord.gg/7PJDdXB

***Orusula*** is licensed under [GPL-3.0 License](https://github.com/imskaa/Orusula/blob/master/LICENSE)
